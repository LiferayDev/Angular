# MEAN Login and Registration

![MEAN Todo](../screenshots/angular-login1.PNG)
#
![MEAN Todo](../screenshots/angular-login2.PNG)


## Setup

Manually clone the repo and then run `npm install`.